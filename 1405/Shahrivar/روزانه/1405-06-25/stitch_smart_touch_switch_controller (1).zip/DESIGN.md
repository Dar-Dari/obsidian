---
name: Obsidian Lumina
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#fff3ea'
  on-tertiary: '#472a00'
  tertiary-container: '#ffd19c'
  on-tertiary-container: '#855300'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter: 1rem
  margin-mobile: 1.25rem
  margin-tablet: 2rem
---

## Brand & Style

The design system embodies the sensory precision of architectural-grade smart switches and luxury IoT automation. Crafted for affluent homeowners, interior architects, and modernists, the aesthetic merges the physical sensation of monolithic capacitive glass faceplates with next-generation digital interface craftsmanship.

### Aesthetic Pillars
- **Dark Obsidian Precision:** Pure matte mineral tones (#0B0F17, #131B2A, #1A2234) emulate laser-cut anodized aluminum, smoked tempered glass, and monolithic slate. Surfaces prioritize absolute black calibration with low-noise grain to eliminate LCD backlight wash.
- **Physical Tactility (Modern Neumorphism & Skeuomorphism):** Interactive touch switches do not sit flat; they appear gently debossed or milled into the panel surface via dual-vector ambient lighting, internal micro-bevels, and soft inner rim highlights.
- **Photonic Luminescence:** Interactive nodes emit focused, optical-grade photon trails using electric cyan, vivid emerald, and warm architectural amber. The glow behaves according to the inverse-square law, scattering subtly through smoked translucent layers.
- **Bilingual Architecture:** Seamless structural symmetry supporting left-to-right (LTR) English and right-to-left (RTL) Persian/Arabic typography without losing layout gravity, tactile depth, or visual cadence.

## Colors

The color architecture is built exclusively for deep dark mode, mimicking the behavior of LED backlights behind frosted architectural glass.

### Foundation & Surfaces
- **Canvas Base (`#070A0F`):** Deepest structural abyss, serving as the viewport substrate.
- **Surface Level 1 - Obsidian Panel (`#0B0F17`):** Primary panel foundation; represents the physical modular wall switch chassis.
- **Surface Level 2 - Smoked Slate (`#131B2A`):** Standard unengaged state for touch switch plates and structural tiles.
- **Surface Level 3 - Elevated Basalt (`#1A2234`):** Modals, flyout sheets, and hover/active capacitive button plates.
- **Border Rim (`rgba(255, 255, 255, 0.08)`):** Micro-hairline rim lighting on upper and left edges.

### Photonic Accent Emitters
- **Electric Cyan (`#00F0FF`):** System primary. Signifies active network connectivity, primary power on/off toggles, and high-tech operational states. Glow core: `rgba(0, 240, 255, 0.45)`.
- **Vivid Emerald (`#10B981`):** System secondary. Represents eco-efficiency, scheduled scenes, verified mesh links, and low-energy modes. Glow core: `rgba(16, 185, 129, 0.4)`.
- **Warm Architectural Amber (`#F59E0B`):** System tertiary. Evokes 2700K incandescent filament ambiance, circadian warmth, and dimmable living spaces. Glow core: `rgba(245, 158, 11, 0.45)`.
- **Warning Crimson (`#EF4444`):** Fault indicators, thermal warnings, and emergency disconnections.

### Monochrome & Text Casts
- **Text Primary (`#F8FAFC`):** Crisp frosted white with 98% opacity for maximum legibility against dark slate.
- **Text Secondary (`#94A3B8`):** Cool slate tint for labels, micro-measurements, and subheadings.
- **Text Tertiary / Muted (`#475569`):** Latent switch status, inactive channels, and disabled modules.

## Typography

The typographical system marries sleek geometric structure with engineering clarity. For English text, **Plus Jakarta Sans** provides a contemporary, high-end display posture, while **Inter** delivers neutral, highly readable body mechanics. For Persian and Arabic layouts, use **Vazirmatn** as the primary font across all headings, body, and label equivalents, retaining identical scale and weight parity. 

**JetBrains Mono** is introduced for technical telemetry, load percentages (e.g., `850W`, `230V`), channel identifiers (`CH-01`, `ZONE-B`), and dimming percentages (`78%`), reinforcing the tactile instrumentation vibe.

### Typographic Rules
- Headings are kept tight with negative tracking to convey mechanical solidity.
- Labels above tactile switches are rendered in small uppercase alphanumeric characters or concise Persian descriptors with generous breathing room.
- Numerical values in switch status indicators always utilize tabular figures (`tnum`) to eliminate micro-jittering during active dimming gestures.

## Layout & Spacing

The layout philosophy mirrors physical luxury switch plates: modular, mathematically balanced, and disciplined around an 8pt base grid with a 4pt sub-grid for delicate tactile offsets.

### Modular Grid Architecture
- **Mobile Viewport (up to 600px):** 4-column fluid layout with `1.25rem` (20px) outer margins and `1rem` (16px) gutters. The primary switchpad interface mimics standard European and UK switch gang enclosures (1-gang, 2-gang, 4-gang, and 8-gang matrix grids).
- **Tablet / Large Mobile (601px to 1024px):** 8-column layout with `2rem` (32px) margins. Gang panels display side-by-side modular tiles with dedicated room-zone partitioning.

### Component Spacing Discipline
- **Inter-Button Gang Separation:** Modular touch switch surfaces maintain an internal boundary gap of exactly `0.75rem` (12px), simulating the milled seam line of physical luxury touch glass plates.
- **Card Padding:** All interactive controller cards feature `1.25rem` (20px) internal breathing room, preventing accidental edge-actuation during one-handed mobile grip.

## Elevation & Depth

Visual hierarchy is constructed through physical surface machining metaphors rather than generic drop shadows. The design system employs a three-layer depth paradigm: **Milled Recess**, **Flush Monolith**, and **Floating Capacitive Plate**.

### Surface Topography

1. **Milled Recess (The Switch Well):**
   - Creates the appearance that the switch button sits within a laser-cut channel.
   - Built with dual inner shadows: `inset 0 3px 6px rgba(0, 0, 0, 0.75)` and `inset 0 -1px 2px rgba(255, 255, 255, 0.04)`.
   - Base surface: `#090D14`.

2. **Flush Monolith (Inactive Switch Plate):**
   - Features a slight convex extrusion.
   - Highlight: Top edge micro-border `linear-gradient(180deg, rgba(255, 255, 255, 0.12) 0%, rgba(255, 255, 255, 0.01) 100%)`.
   - Shadow: `0 8px 20px -4px rgba(0, 0, 0, 0.6)`.

3. **Active Capacitive State (Photon Glow & Extrusion):**
   - The button surface shifts to an active gradient, casting diffused colored light onto the surrounding bevel:
   - Primary (Electric Cyan): `0 0 24px -2px rgba(0, 240, 255, 0.4), 0 0 60px 10px rgba(0, 240, 255, 0.15)`.
   - Amber Channel: `0 0 24px -2px rgba(245, 158, 11, 0.4), 0 0 60px 10px rgba(245, 158, 11, 0.15)`.
   - Emerald Channel: `0 0 24px -2px rgba(16, 185, 129, 0.4), 0 0 60px 10px rgba(16, 185, 129, 0.15)`.

### Glassmorphism Overlays
- Floating dialogs and bottom sheets use a backdrop blur of `24px` over a `rgba(11, 15, 23, 0.78)` wash, sealed with a 1px border of `rgba(255, 255, 255, 0.08)`.

## Shapes

The geometric signature uses unified, precision-curved corner radii (`roundedness: 2`), reflecting the smooth CNC machining of aircraft-grade glass and brushed alloy.

### Radius Schema
- **Switch Controller Plates (Inner Gangs):** `16px` (`1rem`). Matches standard modular wall panel ergonomics.
- **Main Gang Enclosures & Modular Cards:** `20px` to `24px` (`1.25rem` – `1.5rem`). Creates an organic nested corner proportion with the inner touch plates.
- **Micro Badges, Sliders & Pills:** Fully circular / pill-shaped (`9999px`) to visually contrast with the rectilinear modular switch pads.
- **Interactive Thumb Controls:** Perfectly circular touch nodes with subtle debossed centers.

## Components

### 1. Modular Touch Switches (کلید لمسی)
- **Structure:** Square or tall-aspect touch plates arranged in single, dual, triple, or quad gang configurations.
- **Visuals:** Smoked matte obsidian base (`#131B2A`). An illuminated micro-icon or circular status indicator (10px ring) sits centered or top-aligned.
- **States:**
  - *Off:* Icon colored `#475569`; rim has faint white trace (`rgba(255, 255, 255, 0.04)`).
  - *On:* Icon glows in target color (Cyan/Emerald/Amber); an internal radial gradient illuminates the center of the key (`radial-gradient(circle at center, rgba(accent, 0.25) 0%, transparent 70%)`); soft colored halo spreads to the outer bezel.
  - *Pressed:* Slight scale down (`transform: scale(0.97)`), inner shadow intensifies to replicate mechanical deflection.

### 2. Linear Arc & Slider Dimmer
- **Track:** Recessed groove (`height: 12px` or `width: 64px` for vertical panel dimmers) with deep inset shadows.
- **Fill:** Gradient glow extending from the origin to the current value, backed by a neon shadow.
- **Thumb:** 28px circular machined pill featuring a center photonic pinhole LED.

### 3. Controller Cards (Smart Gang Chassis)
- Modular containers holding grouped switch nodes (e.g., "Living Room Master Unit").
- Framed by a subtle gradient micro-border (`1px solid rgba(255, 255, 255, 0.07)`).
- Top bar contains channel identifiers (`CH-1 to CH-4`), aggregate wattage telemetry via JetBrains Mono, and a discrete quick-kill master toggle.

### 4. Status Badges & Pills
- Small, hyper-refined telemetry markers (`JetBrains Mono`, 11px).
- Dark semi-transparent pill container (`rgba(0, 0, 0, 0.4)`) with a 6px breathing LED dot that pulses smoothly via a CSS opacity/scale animation (`ease-in-out`, 2s duration) indicating Zigbee/Matter mesh connectivity.

### 5. Buttons (Global Controls)
- **Primary:** Neon-rimmed obsidian button with subtle colored glass backdrop blur. Hover/tap triggers full glowing illumination.
- **Secondary:** Smoked slate pill with white text and `rgba(255, 255, 255, 0.06)` border.
- **Danger:** Matte charcoal button with warm crimson glow edge.

### 6. Inputs & Fields
- Dark debossed containers (`#090D14`) with sharp baseline indicators.
- On focus: The hairline border shifts to Electric Cyan with an ambient `0 0 12px rgba(0, 240, 255, 0.25)` outward diffusion.
- Placeholder text: `#475569`. Entered text: `#F8FAFC`. Support bidirectional RTL alignment for Persian scene and device naming.